<?php $__env->startSection('content'); ?>

<div class="page-wrapper">

    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">Dashboard</h4>
                <div class="ml-auto text-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-md-flex align-items-center">
                            <div>
                                <h3 class="card-title capitalize">Hello <?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?>, Welcome To Thinknyx Connect</h3>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>


        <div class="card" style="margin-top: 0px;">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-5">
                        <div class="box box-success">
                            <div class="panel">

                                <!--<div class="panel-heading">
                                    <span class="panel-title">Personal Details</span>
                                </div>-->

                                <div class="panel-body pn pb5">
                                    <!--<hr class="short br-lighter">-->

                                    <div class="box-body no-padding">

                                        <table class="table">
                                            <tbody>
                                                

                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-tags"></i>
                                                    </td>
                                                    <td><strong>Employee ID</strong></td>
                                                    <td><?php echo e($user->emp_id); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-tags"></i>
                                                    </td>
                                                    <td><strong>First name</strong></td>
                                                    <td class="capitalize"><?php echo e($user->first_name); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-tags"></i>
                                                    </td>
                                                    <td><strong>Last name</strong></td>
                                                    <td class="capitalize"><?php echo e($user->last_name); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-tags"></i>
                                                    </td>
                                                    <td><strong>Phone number</strong></td>
                                                    <td><?php echo e($user->phone); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-tags"></i>
                                                    </td>
                                                    <td><strong>Designation</strong></td>
                                                    <td><?php echo e($user->designation); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-tags"></i>
                                                    </td>
                                                    <td><strong>Gender</strong></td>
                                                    <td class="capitalize"><?php echo e($user->gender); ?></td>
                                                </tr>

                                                
                                            </tbody>
                                        </table>
                                        

                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="box box-success">
                            <div class="panel">


                                <div class="panel-body pn pb5">


                                    <div class="box-body no-padding">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-credit-card"></i></td>
                                                    <td><strong>Office</strong></td>
                                                    <td class="capitalize"><?php echo e($user->city); ?></td>

                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-credit-card"></i></td>
                                                    <td><strong>Manager</strong></td>
                                                    <td class="capitalize"><?php echo e($user->manager); ?></td>
                                                </tr>
                                                <tr>

                                                    <td style="width: 10px" class="text-center"><i class="fa fa-tags"></i></td>
                                                    <td><strong>Department</strong></td>
                                                    <td class="capitalize"><?php echo e($user->department); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-calendar-times"></i>
                                                    </td>
                                                    <td><strong>Join date</strong></td>
                                                    <td><span id="join_date" style="display: none;"><?php echo e($user->join_date); ?></span> <?php echo e(\Carbon\Carbon::parse($user->join_date)->format('d-m-Y')); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-universal-access"></i></td>
                                                    <td><strong>Thinknyx Tenure (Years)</strong></td>
                                                    <td><span id='tenure'><?php echo e($user->tenure); ?></span></td>
                                                </tr>

                                                
                                                <tr>
                                                    <td style="width: 10px" class="text-center"><i class="fa fa-code"></i>
                                                    </td>
                                                    <td><strong>Job type (Status)</strong></td>
                                                    <td class="capitalize"><?php echo e($user->job_type); ?></td>
                                                </tr>



                                            </tbody>
                                        </table>
                                    </div>


                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-md-flex align-items-center">
                            <div>
                                <h4 class="card-title">Birthdays Current Month</h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                
                                    <div id="calendar">
                                        <div class="table-responsive">
                                            <table id="zero_config" class="table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>S.N</th>
                                                        <th>Username</th>
                                                        <th>DOB</th>
                                                        <th>Email</th>
                                                        
                                                       
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th><?php echo e($loop->index+1); ?></th>
                                                        <td><?php echo e($user->username); ?></td>
                                                        <td><?php echo e($user->dob); ?></td>
                                                        <td><?php echo e($user->email); ?></td>
                                                    </tr>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            
                                        </div>

                                    </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-md-flex align-items-center">
                            <div>
                                <h4 class="card-title">Weekly Timesheet</h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">

                                <div id="calendar">

                                    <div class="table-responsive">
                                        <table id="zero_config" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>S.N.</th>
                                                    <th>Employee name</th>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop -> index+1); ?></td>
                                                    <td><?php echo e($timesheet->users->username); ?></td>
                                                    <td><?php echo e($timesheet->timesheet_date); ?></td>
                                                    <td><?php echo e(floor($timesheet->totalmins/60)); ?>:<?php echo e($timesheet->totalmins%60); ?></td>
                                                    
                                                </tr>
                                            </tbody>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>




        <?php /* <div class="row">
          <!-- Column -->
          <div class="col-md-6 col-lg-4 col-xlg-3">
          <div class="card card-hover">
          <div class="box bg-success text-center">
          <h1 class="font-light text-white"><i class="mdi mdi-chart-areaspline"></i></h1>
          <h5 class="m-b-0 m-t-5 text-white">{{ $users->total() }}</h5>
          <h6 class="text-white">Total employees</h6>
          </div>
          </div>
          </div>
          <!-- Column -->
          <div class="col-md-6 col-lg-2 col-xlg-3">
          <div class="card card-hover">
          <div class="box bg-warning text-center">
          <h1 class="font-light text-white"><i class="mdi mdi-collage"></i></h1>
          <h5 class="m-b-0 m-t-5 text-white">25</h5>
          <h6 class="text-white">Total leaves</h6>
          </div>
          </div>
          </div>
          <!-- Column -->
          <div class="col-md-6 col-lg-2 col-xlg-3">
          <div class="card card-hover">
          <div class="box bg-danger text-center">
          <h1 class="font-light text-white"><i class="mdi mdi-border-outside"></i></h1>
          <h5 class="m-b-0 m-t-5 text-white">2</h5>
          <h6 class="text-white">On leave</h6>
          </div>
          </div>
          </div>

          <div class="col-md-6 col-lg-2 col-xlg-3">
          <div class="card card-hover">
          <div class="box bg-cyan text-center">
          <h1 class="font-light text-white"><i class="mdi mdi-view-dashboard"></i></h1>
          <h5 class="m-b-0 m-t-5 text-white">6</h5>
          <h6 class="text-white">Designation</h6>
          </div>
          </div>
          </div>
          </div> */ ?>

        <!--<div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-md-flex align-items-center">
                            <div>
                                <h4 class="card-title">Calendar</h4>
                            </div>
                        </div>
                        <div class="row">
                                <div class="col-lg-12">
                                    <div class="card-body b-l calender-sidebar">
                                        <div id="calendar"></div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->

    </div> 

    <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    function ageCalculate() {

        var birthDate = document.getElementById('join_date').innerHTML;
        // document.getElementById("age").innerHTML = d;
        var mdate = birthDate.toString();
        var yearThen = parseInt(mdate.substring(0, 4), 10);
        var monthThen = parseInt(mdate.substring(5, 7), 10);
        var dayThen = parseInt(mdate.substring(8, 10), 10);

        var today = new Date();
        var birthday = new Date(yearThen, monthThen - 1, dayThen);
        //   alert(today.valueOf() + " " + birthday.valueOf());
        var differenceInMilisecond = today.valueOf() - birthday.valueOf();
        //  alert(differenceInMilisecond);
        var year_age = Math.floor(differenceInMilisecond / 31536000000);
        var day_age = Math.floor((differenceInMilisecond % 31536000000) / 86400000);

        var month_age = Math.floor(day_age / 30);
        day_age = day_age % 30;
        //var tMnt = (month_age + (year_age * 12));
        //var tDays = (tMnt * 30) + day_age;

        if (isNaN(year_age) || isNaN(month_age) || isNaN(day_age)) {
            document.getElementById('tenure').innerHTML = 0;
        } else {
            document.getElementById('tenure').innerHTML = year_age + " Years " + month_age + " Months " + day_age + " Days";
        }
    }
    $( document ).ready(function() {
      ageCalculate();
    });  
</script>

<script src="<?php echo e(asset('admin-panel/assets/libs/flot/excanvas.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/flot/jquery.flot.pie.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/flot/jquery.flot.time.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/flot/jquery.flot.stack.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/flot/jquery.flot.crosshair.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/dist/js/pages/chart/chart-page-init.js')); ?>"></script>

<!--  -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\connect-new\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>