 <footer class="footer text-center">
    All Rights Reserved
</footer>
<?php /**PATH C:\xampp\htdocs\connect-new\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>