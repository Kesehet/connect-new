<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Timesheet List</h5>
                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>S.N.</th>
                            <th>Comments</th>
                            <th>Time</th>
                            <th>Options</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $timesheetdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheetdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr id="row<?php echo e($timesheetdetail->id); ?>">
                                <td><?php echo e($loop -> index+1); ?></td>
                                <td><?php echo e($timesheetdetail->comments); ?></td>
                                <td><?php echo e(floor($timesheetdetail->working_mintus/60)); ?>:<?php echo e($timesheetdetail->working_mintus%60); ?></td>
                                <td>
                                    <button id="deleteTeetdet" class="btn btn-sm btn-danger" data-url="<?php echo e(route('timesheet.ajaxdelete',$timesheetdetail->id)); ?>">Delete</button>
                                </td>
                            </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\connect-new\resources\views/admin/timesheet/ajaxindex.blade.php ENDPATH**/ ?>