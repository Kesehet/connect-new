<?php $__env->startSection('content'); ?>

    <div id="main-wrapper">

        <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-wrapper">

            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">User Guide</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('download.userguide')); ?>">User Guide</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container-fluid">
                <div class="row" >
                    <div class="col-md-12">
                        <div class="card">
                             <?php if($fileshowflag == 'YES'): ?>
                            <embed src="<?php echo e(url(asset($user_guide))); ?>" style="width:1070px; height:600px;" frameborder="0">
                            <?php endif; ?>
                            <?php if($fileshowflag == 'NO'): ?>
                            <h4 class="card-title" style="text-align: center;height: 200px; padding-top: 103px;">No User Guide Found</h4>
                            <?php endif; ?>
                            <!--<style type="text/css">
                            #myiframenew {width:1070px; height:480px;} 
                            </style>
                            <iframe name="myiframenew" id="myiframe" src="<?php echo e(asset('uploads/companypolicy/Thinknyx_Employee Handbook_Leave_Policy_2020_v1.pdf')); ?>">-->
                             
                        </div>
                    </div>
                </div>
                
            </div>


            <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\connect-new\resources\views/admin/download/userguide.blade.php ENDPATH**/ ?>