
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>

<!---->

<!---->
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('admin-panel/assets/libs/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin-panel/assets/extra-libs/sparkline/sparkline.js')); ?>"></script>
<!--Wave Effects -->
<script src="<?php echo e(asset('admin-panel/dist/js/waves.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('admin-panel/dist/js/sidebarmenu.js')); ?>"></script>

<script src="<?php echo e(asset('admin-panel/assets/libs/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/fullcalendar/dist/fullcalendar.min.js')); ?>"></script>

<!---->

<script src="<?php echo e(asset('admin-panel/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/dist/js/jquery-ui.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin-panel/dist/js/custom.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/assets/libs/fullcalendar/dist/fullcalendar.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-panel/dist/js/pages/calendar/cal-init.js')); ?>"></script>

<!---->
<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>

<!---->
<!---->
<script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>

<?php /**PATH C:\xampp\htdocs\connect-new\resources\views/admin/includes/scripts.blade.php ENDPATH**/ ?>