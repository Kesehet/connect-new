


<aside class="left-sidebar" data-sidebarbg="skin5">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav" class="p-t-30">
                
                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('dashboard')); ?>" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard</span></a></li>
                 
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin', 'isManager'])): ?>
                <?php /*<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="{{route('user')}}" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">User Management</span></a></li>*/ ?>
                <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="<?php echo e(route('user')); ?>" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Users</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                        <li class="sidebar-item"><a href="<?php echo e(route('user')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Users </span></a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin'])): ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('user.create')); ?>" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Add </span></a></li>
                        <?php endif; ?>        
                    </ul>
                </li> 
                <?php endif; ?>
                
                <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Leaves</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isEmployee', 'isManager'])): ?> 
                        <li class="sidebar-item"><a href="<?php echo e(route('leave.create')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Apply Leave</span></a></li>
                        <?php endif; ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('leave')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Leave List</span></a></li>
                        
                    </ul>
                </li>
                
                <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Tasks</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin', 'isManager'])): ?> 
                        <li class="sidebar-item"><a href="<?php echo e(route('tasks.create')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Add Tasks</span></a></li>
                    <?php endif; ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('tasks.index')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Tasks List</span></a></li>
                    </ul>
                </li>


                <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Timesheets</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                        <li class="sidebar-item"><a href="<?php echo e(route('timesheet.create')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Add Timesheet</span></a></li>
                        <li class="sidebar-item"><a href="<?php echo e(route('timesheet')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Timesheet List</span></a></li>
                    </ul>
                </li>

               <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Goals</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isEmployee','isManager'])): ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('goal')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">My Goals</span></a></li>
                        <?php endif; ?>  
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin', 'isManager'])): ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('goal.userlist')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Goals List</span></a></li>
                        <?php endif; ?>
                    </ul>
               </li>


               <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Appraisals</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                        

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isEmployee', 'isManager'])): ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('appraisal.create')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">My Appraisal</span></a></li>
                        <?php endif; ?>

				   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin', 'isManager'])): ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('appraisal')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu">Appraisal List</span></a></li>
                        <?php endif; ?>
                        
                       
                    </ul>
               </li>
              
                <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Settings</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                           <li class="sidebar-item"><a href="<?php echo e(route('profile')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> My profile </span></a></li>
                           <li class="sidebar-item"><a href="<?php echo e(route('profile.edit')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Edit profile </span></a></li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin'])): ?>
                            <li class="sidebar-item"><a href="<?php echo e(route('attendancelog')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Attendance log </span></a></li>
                            <li class="sidebar-item"><a href="<?php echo e(route('profile.addfy')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Add FY </span></a></li>
                            <?php endif; ?>
                            <li class="sidebar-item"><a href="<?php echo e(route('change.password')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Change Password </span></a></li>
                    </ul>
                </li>
                <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Documents</span></a>
                    <ul aria-expanded="false" class="collapse  first-level">
                        <li class="sidebar-item"><a href="<?php echo e(route('download.holidaylist')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Holiday List </span></a></li>
                        <li class="sidebar-item"><a href="<?php echo e(route('download.companypolicy')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Company Policy </span></a></li>
                        <li class="sidebar-item"><a href="<?php echo e(route('download.orggoalsdoc')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Organizational Goals </span></a></li>
                        <li class="sidebar-item"><a href="<?php echo e(route('download.performance')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Performance Process</span></a></li>
                        <li class="sidebar-item"><a href="<?php echo e(route('download.userguide')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> User Guide</span></a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin', 'isManager'])): ?>
                        <li class="sidebar-item"><a href="<?php echo e(route('download.adminguide')); ?>" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Admin Guide</span></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <li class="sidebar-item"> 
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();"  aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Logout</span></a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    </form>
                </li>
                
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside><?php /**PATH C:\xampp\htdocs\connect-new\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>